from paquete.hola.saludos import saludar
from paquete.adios.despedidas import Despedida

saludar()
Despedida()