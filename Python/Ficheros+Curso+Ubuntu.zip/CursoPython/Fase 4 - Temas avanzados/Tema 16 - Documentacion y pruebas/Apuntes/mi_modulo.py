"""Este es el docstring del módulo"""

def despedir():
    """Este es el docstring de la función despedir"""
    print("Adiós! Me estoy despidiendo desde la función despedir() del módulo")

def saludar():
    """Este es el docstring de la función saludar"""
    print("Hola! Te estoy saludando desde la función saludar() del módulo")